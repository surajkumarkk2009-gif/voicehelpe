package com.voicehelper.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private var speechRecognizer: SpeechRecognizer? = null
    private var listening = false
    private var restarting = false
    private lateinit var statusText: TextView
    private lateinit var transcriptText: TextView
    private lateinit var toggleButton: Button
    private lateinit var audioManager: AudioManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        buildUi()
        requestNeededPermissions()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "इस फोन पर आवाज़ पहचानने की सुविधा उपलब्ध नहीं है।"
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFFF4F7FB.toInt())
        }
        val title = TextView(this).apply {
            text = "🎙 VoiceHelper"
            textSize = 28f
            setTextColor(0xFF102A43.toInt())
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            text = "सिस्टम बंद है"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 18)
        }
        toggleButton = Button(this).apply {
            text = "सिस्टम चालू करें"
            setOnClickListener {
                if (listening) stopListening() else startListening()
            }
        }
        val hint = TextView(this).apply {
            text = "उदाहरण: YouTube खोलो • वॉल्यूम थोड़ा बढ़ाओ • गाना बंद करो • पापा को कॉल लगाओ"
            textSize = 15f
            setTextColor(0xFF334E68.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 16)
        }
        transcriptText = TextView(this).apply {
            text = "आपकी बात यहाँ दिखाई देगी।"
            textSize = 16f
            setTextColor(0xFF243B53.toInt())
            setPadding(0, 12, 0, 12)
        }
        val scroll = ScrollView(this).apply {
            addView(transcriptText)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(statusText, LinearLayout.LayoutParams(-1, -2))
        root.addView(toggleButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(hint, LinearLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun requestNeededPermissions() {
        val missing = mutableListOf<String>()
        listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
            .forEach { if (checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED) missing.add(it) }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 100)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("इस फोन में Speech Recognition उपलब्ध नहीं है।")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        listening = true
        toggleButton.text = "सिस्टम बंद करें"
        statusText.text = "सुन रहा हूँ… बोलकर आदेश दें"
        createRecognizer()
        listenAgain()
    }

    private fun createRecognizer() {
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                statusText.text = "सुन रहा हूँ…"
                restarting = false
            }
            override fun onBeginningOfSpeech() { statusText.text = "आपकी बात सुन रहा हूँ…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { statusText.text = "समझ रहा हूँ…" }
            override fun onError(error: Int) {
                if (listening && !restarting) {
                    restarting = true
                    statusText.postDelayed({ if (listening) listenAgain() }, 700)
                }
            }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val command = words?.firstOrNull().orEmpty()
                if (command.isNotBlank()) {
                    transcriptText.text = "आपने कहा: $command"
                    handleCommand(command)
                }
                if (listening && !restarting) {
                    restarting = true
                    statusText.postDelayed({ if (listening) listenAgain() }, 500)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun listenAgain() {
        if (!listening) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            statusText.text = "सुनने में दिक्कत हुई; फिर कोशिश कर रहा हूँ…"
            statusText.postDelayed({ if (listening) listenAgain() }, 1000)
        }
    }

    private fun stopListening() {
        listening = false
        restarting = false
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
        statusText.text = "सिस्टम बंद है"
        toggleButton.text = "सिस्टम चालू करें"
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale.forLanguageTag("hi-IN"))
            .replace("यूट्यूब", "youtube")
            .replace("व्हाट्सएप", "whatsapp")
            .replace("वाट्सएप", "whatsapp")
            .replace("क्रोम", "chrome")
            .replace("कैमरा", "camera")
            .replace("सेटिंग्स", "settings")
            .replace("सेटिंग", "settings")
            .replace("वॉल्यूम", "volume")
            .replace("आवाज", "volume")
            .replace("आवाज़", "volume")

        when {
            listOf("सिस्टम बंद", "बंद हो जाओ", "सुनना बंद", "voicehelper बंद").any { c.contains(it) } -> stopListening()
            c.contains("volume") && listOf("बढ़ा", "ज्यादा", "increase", "तेज").any { c.contains(it) } -> changeVolume(1, c)
            c.contains("volume") && listOf("कम", "घटा", "धीमा", "decrease").any { c.contains(it) } -> changeVolume(-1, c)
            c.contains("म्यूट") || c.contains("आवाज़ बंद") -> audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
            c.contains("गाना बंद") || c.contains("music बंद") || c.contains("रोक दो") || c.contains("रोकना") -> {
                sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
                toast("गाना रोकने का आदेश भेजा।")
            }
            c.contains("अगला गाना") || c.contains("next song") -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
            c.contains("पिछला गाना") || c.contains("previous song") -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            c.contains("कॉल") || c.contains("फोन लगाओ") || c.contains("फोन करो") -> callContact(raw)
            c.contains("youtube") -> openApp("com.google.android.youtube", "YouTube")
            c.contains("whatsapp") -> openApp("com.whatsapp", "WhatsApp")
            c.contains("chrome") -> openApp("com.android.chrome", "Chrome")
            c.contains("spotify") -> openApp("com.spotify.music", "Spotify")
            c.contains("camera") -> openIntent(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE), "कैमरा")
            c.contains("settings") -> openIntent(Intent(android.provider.Settings.ACTION_SETTINGS), "सेटिंग्स")
            c.contains("गाना बजाओ") || c.contains("music चलाओ") || c.contains("गाना चलाओ") -> {
                openApp("com.google.android.youtube", "YouTube")
                toast("गाना खोजने के लिए YouTube खुल रहा है।")
            }
            else -> toast("यह आदेश अभी उपलब्ध नहीं है। ऐप खोलने के लिए ऐप का नाम बोलें।")
        }
    }

    private fun changeVolume(direction: Int, command: String) {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val small = listOf("थोड़ा", "जरा", "ज़रा", "little", "slightly").any { command.contains(it) }
        val percent = Regex("(\\d{1,3})\\s*(प्रतिशत|percent|%)").find(command)?.groupValues?.get(1)?.toIntOrNull()
        val target = when {
            percent != null -> (max * percent.coerceIn(0, 100) / 100.0).toInt()
            direction > 0 -> (current + if (small) 1 else 3).coerceAtMost(max)
            else -> (current - if (small) 1 else 3).coerceAtLeast(0)
        }
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        toast("वॉल्यूम बदल दिया।")
    }

    private fun sendMediaKey(keyCode: Int) {
        val down = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode)
        val up = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode)
        audioManager.dispatchMediaKeyEvent(down)
        audioManager.dispatchMediaKeyEvent(up)
    }

    private fun callContact(raw: String) {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            toast("कॉल के लिए संपर्क अनुमति दें।")
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 100)
            return
        }
        val name = raw.replace(Regex("(?i)कॉल|लगाओ|लगाना|फोन|करो|कर दो|प्लीज|please"), "")
            .replace("को", "").replace("पर", "").trim()
        if (name.isBlank()) {
            toast("किसे कॉल करना है, उसका नाम बोलें।")
            return
        }
        var number: String? = null
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"),
                null
            )
            if (cursor != null && cursor.moveToFirst()) {
                number = cursor.getString(0)
            }
        } catch (_: Exception) {
        } finally {
            cursor?.close()
        }
        if (number.isNullOrBlank()) {
            toast("संपर्क नहीं मिला: $name")
            return
        }
        try {
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))
            } else {
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
            }
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        }
    }

    private fun openApp(packageName: String, label: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } else {
            toast("$label इस फोन में इंस्टॉल नहीं है।")
        }
    }

    private fun openIntent(intent: Intent, label: String) {
        try { startActivity(intent) } catch (_: Exception) { toast("$label नहीं खुल सका।") }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        listening = false
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }
}
