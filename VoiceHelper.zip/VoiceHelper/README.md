# VoiceHelper (starter project)

This is a starter Android project for a Hindi voice-command helper.

## Features included
- Start/stop listening from the app screen.
- Attempts to restart speech recognition after each command/error while the app remains open.
- Opens installed YouTube, WhatsApp, Chrome, Spotify, Camera and Settings (where available).
- Basic media pause/next/previous media-key commands.
- Basic music volume up/down commands.
- Searches contacts by name and initiates a call/dial action when permissions are granted.

## Important limitations
- This is a starter build, not a fully tested release. Speech recognition depends on the phone's installed speech service and internet/settings.
- Continuous listening is designed for while the app is open. Android may stop microphone access in the background or during calls.
- Playing a specific song/playlist inside YouTube/Spotify requires their supported APIs/deep links or user interaction; this starter opens YouTube rather than guaranteeing a particular track.
- Contact matching can be ambiguous. Check the contact and call permission before relying on voice dialing.
- For safety, test with the app open and verify commands before using it for important calls.

## Build
Open the `VoiceHelper` folder in Android Studio, or upload this project to GitHub and run the included workflow. The workflow expects the repository root to contain the `VoiceHelper` folder.
